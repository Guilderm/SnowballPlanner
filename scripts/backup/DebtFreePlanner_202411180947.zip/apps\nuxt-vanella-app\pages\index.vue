<!-- pages/index.vue -->
<template>
  <div>
    <h1>Welcome to DebtFreePlanner</h1>
  </div>
</template>
