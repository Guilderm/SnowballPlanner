// prettier.config.js

export default {
  printWidth: 80,
  plugins: ['prettier-plugin-tailwindcss'],
};