<!-- apps\public-site\app\app.vue -->

<template>
  <div>
    <NuxtRouteAnnouncer />
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </div>
</template>

<script setup lang="ts">
// No additional script needed, but we define it as TypeScript
</script>

<style scoped>
/* You can add global styles here if needed */
</style>
