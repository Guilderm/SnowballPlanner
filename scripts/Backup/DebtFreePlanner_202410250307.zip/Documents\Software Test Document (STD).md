# Software Test Document (STD)

Mutation Testing
<https://en.wikipedia.org/wiki/Mutation_testing>

Software test documentation
<https://en.wikipedia.org/wiki/Software_test_documentation>
