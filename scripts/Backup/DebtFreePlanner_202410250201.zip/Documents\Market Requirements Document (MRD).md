# [The Product Market-Fit Pyramid](https://medium.com/paper-planes/the-product-market-fit-pyramid-292c1ab49ecc)
