<!-- C:\Repository\DebtFreePlanner\apps\public-site\ui\components\coming-soon\LaunchAnnouncement.vue -->
<template>
  <div class="launch-announcement text-center">
    <h1 class="text-4xl font-bold text-white md:text-5xl">
      A powerful web-based tool to
    </h1>
    <h1 class="text-4xl font-bold text-white md:text-5xl">
      Strategically Plan Your Journey to a Debt-Free Living
    </h1>
    <div class="mt-8">
      <p class="text-3xl font-semibold text-white">
        Launching on <span class="text-white">December 1st, 2024</span>
      </p>
    </div>
  </div>
</template>

<script setup>
/* No additional script needed */
</script>

<style scoped>
.launch-announcement {
  margin-top: 2rem;
}
</style>
