# Developer Tools Guide

## Project Management

- **Issue Tracking and Roadmapping:** Managed using [**Linear.app**](https://linear.app/)
  - **Purpose:** Organize user stories, manage the product backlog, and plan sprints effectively.
  - **Features Used:**
    - User Story Management
    - Sprint Planning
    - Roadmap Visualization
