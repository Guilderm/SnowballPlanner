
declare module '#app/defaults' {
  type DefaultAsyncDataErrorValue = undefined
  type DefaultAsyncDataValue = undefined
  type DefaultErrorValue = undefined
  type DedupeOption = 'cancel' | 'defer'
}