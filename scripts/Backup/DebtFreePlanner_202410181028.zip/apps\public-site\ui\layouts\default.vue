<!-- C:\Repository\DebtFreePlanner\apps\public-site\ui\layouts\default.vue -->
<template>
  <div class="flex flex-col min-h-screen">
    <Navbar />
    <main class="flex-grow">
      <NuxtPage />
    </main>
    <Footer />
  </div>
</template>

<script setup>
import Navbar from '@/components/Navbar.vue';
import Footer from '@/components/Footer.vue';
</script>

<style scoped>
/* Add any layout-specific styles here if necessary */
</style>
