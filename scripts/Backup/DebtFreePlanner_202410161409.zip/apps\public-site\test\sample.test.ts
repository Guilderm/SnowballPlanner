// test/sample.test.ts
import { describe, it, expect } from 'vitest'

describe('Sample Test', () => {
  it('should pass', () => {
    expect(true).toBe(true)
  })
})
