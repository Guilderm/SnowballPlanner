<template>
  <div>
    <NuxtRouteAnnouncer />
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </div>
</template>

<script setup>
/* No additional script needed  */
</script>

<style>
/* You can add global styles here if needed */
</style>
